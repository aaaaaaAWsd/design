﻿namespace InventoryManagement
{
    partial class unit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxU = new System.Windows.Forms.TextBox();
            this.buttonAddU = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.buttonDeleteU = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Add Unit :";
            // 
            // textBoxU
            // 
            this.textBoxU.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxU.Location = new System.Drawing.Point(108, 60);
            this.textBoxU.Name = "textBoxU";
            this.textBoxU.Size = new System.Drawing.Size(262, 23);
            this.textBoxU.TabIndex = 1;
            // 
            // buttonAddU
            // 
            this.buttonAddU.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddU.Location = new System.Drawing.Point(192, 107);
            this.buttonAddU.Name = "buttonAddU";
            this.buttonAddU.Size = new System.Drawing.Size(81, 27);
            this.buttonAddU.TabIndex = 2;
            this.buttonAddU.Text = "Add";
            this.buttonAddU.UseVisualStyleBackColor = true;
            this.buttonAddU.Click += new System.EventHandler(this.buttonAddU_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(392, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(431, 381);
            this.dataGridView1.TabIndex = 3;
            // 
            // buttonDeleteU
            // 
            this.buttonDeleteU.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDeleteU.Location = new System.Drawing.Point(570, 408);
            this.buttonDeleteU.Name = "buttonDeleteU";
            this.buttonDeleteU.Size = new System.Drawing.Size(79, 30);
            this.buttonDeleteU.TabIndex = 4;
            this.buttonDeleteU.Text = "Delete";
            this.buttonDeleteU.UseVisualStyleBackColor = true;
            this.buttonDeleteU.Click += new System.EventHandler(this.buttonDeleteU_Click);
            // 
            // unit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Orange;
            this.ClientSize = new System.Drawing.Size(835, 450);
            this.Controls.Add(this.buttonDeleteU);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.buttonAddU);
            this.Controls.Add(this.textBoxU);
            this.Controls.Add(this.label1);
            this.Name = "unit";
            this.Text = "unit";
            this.Load += new System.EventHandler(this.unit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxU;
        private System.Windows.Forms.Button buttonAddU;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonDeleteU;
    }
}